let food1s = document.getElementById('food1');
let food2s = document.getElementById('food2');
let food3s = document.getElementById('food3');
let food4s = document.getElementById('food4');
let food5s = document.getElementById('food5');
let foods = document.getElementById('food');

food1s.addEventListener('click',()=>{
   foods.style. backgroundImage= url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQzhPpD1PHvx4pRDByAqmZf0eOblxUVJtpIDICYtx6e4yJwlvZfYxL37VZ9l-RZmFD746Q&usqp=CAU');
    
})
food2s.addEventListener('click',()=>{
    foods.style.backgroundImage=url ('https://www.pngitem.com/pimgs/m/57-576392_seared-tuna-steak-reshttpstaurant-food-top-view-hd.png');
})
food3s.addEventListener('click',()=>{
    foods.style.backgroundImage=url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQhhfQ6pJ8KstxPQ-h69M3unjpsfRwRXkrfXg&usqp=CAU');
})
food4s.addEventListener('click',()=>{
    foods.style.backgroundImage = url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSFkolczjezYgSqJFnKNnnv_oSWQZ3HDDWvRA4JdR4QB62_7dFcr7C_ucJdwwZTKnSUq1Q&usqp=CAU') ;
})
food5s.addEventListener("click",()=>{
   foods.style.backgroundImage= url('https://www.vhv.rs/dpng/d/520-5206885_dish-food-nem-rn-cuisine-spring-roll-g.png');
    
})